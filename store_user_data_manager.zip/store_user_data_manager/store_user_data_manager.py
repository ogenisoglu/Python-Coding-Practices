prices_list=open("C:\\Users\\X\\Desktop\\python workspace\\homeworks\\ceng113 hw2\\PriceList.txt","r").readlines()
students=("").join(open("C:\\Users\\X\\Desktop\\python workspace\\homeworks\\ceng113 hw2\\PurchaseHistory.txt","r").readlines()).split("DAY#")   #Divide text into days
del students[0]                                                                 #Delete empty element  
prices=[]                                                                       #Create lists that will be used later
days=[]                                                                         
price_list=""
student_spent=[]
total_revenue=0
for i in prices_list:
    i=i.split("#")
    x=[i[0].strip(),(i[1].strip())]                                             #These 2 for loops creates a list that will be used like dictionaries
    prices.append(x)                                                            #(We aren't allowed to use dictionaries)
for i in prices:
    a=((17-len(i[0]))*(" ")).join(i)
    price_list=price_list+a+("\n\n")
for i in students:
    daily_product=[]                                                            #This big loop is used to create a list named days and this is our main list we work
    day=[]                                                                      #This list includes which student how much spent day by day
    a=i.split("\n")                                                             #Additionally includes a list which has which product how many times bought day by day 
    day.append(a[0])    
    daily_revenue=0
    for j in range(len(a)):
        person_bought=[]
        if a[j]!="":
            if j!=0:
                person_bought.append(a[j].split("-")[0][7])
                eaten=a[j].split("-")[1].split(",")
                summ=0
                for fod in eaten:
                    fod=fod.strip()
                    for l in prices:
                        if l[0]==fod:
                            summ=summ+int(l[1])
                            daily_product.append(fod)
                daily_revenue=daily_revenue+summ
                person_bought.append(summ)
                day.insert(1,person_bought)
    day.append(daily_product)
    day.append(daily_revenue)
    days.append(day)
    total_revenue=total_revenue+daily_revenue
total_product=[]
for i in days:
    for j in i[len(i)-2]:
        total_product.append(j)                                                 #Calculate how many products sold, and which one(s) bought the most
most_selling=[]
most_times=0
x=0
for i in prices:
    y=0
    for j in total_product:
        if j==i[0]:
            y=y+1
    if y>x:
        x=y
        most_times=y
        most_selling=[]
        most_selling.append(i[0])
    elif x==y:
        most_selling.append(i[0])
start="Press 1 to product and price list\nPress 2 to total revenue and most selling product(s) in total\nPress 3 to daily revenue and most selling product(s) in a day\nPress 4 to total payment for a student\nPress 0 to exit\n\nchoice="
choice=str(input(start))
while choice!="0":                                                              #Take a number between 1 and 4 from user
    if choice=="1":
        print(price_list)
    elif choice=="2":
        print("Total revenue= "+str(total_revenue)+"\nMost selling product(s) in TOTAL ( "+str(most_times)+" sales)")
        for i in most_selling:
            print(i)
    elif choice=="3":   
        a=str(input("Select day between 1 and "+str(len(days))+"\n\nday="))
        x=0
        today_revenue=0
        most_selling_today=[]
        today=days[int(a)-1]
        for i in prices:
            y=0
            for j in today[len(today)-2]:
                if i[0]==j:
                    today_revenue=today_revenue+int(i[1])
                    y=y+1
                    ac=j
            if y>x and y>0:
                x=y
                most_selling_today=[ac]
            elif y==x and y>0:
                most_selling_today.append(ac)
        print("Day "+a+" total revenue= "+str(today_revenue)+"\nMost selling product(s)( "+str(x)+" sales)")
        for i in most_selling_today:
            print(i)
    elif choice=="4":
        biggest_student_number="0"
        for i in days:
            for j in range(1,len(i)-2):
                if i[j][0]>biggest_student_number:
                    biggest_student_number=i[j][0]
        st_id=str(input("Select student id between 1 and "+biggest_student_number+"\n\nstudent id="))
        astudent_total=0
        for i in days:
            for j in range(1,len(i)-2):
                if i[j][0]==st_id:
                    astudent_total=astudent_total+i[j][1]
        print("Total payment of student",st_id,"=",astudent_total)
    else:
        choice=str(input("Enter a number between 1 and 4="))
        continue
    choice=str(input(start))